# History

## 0.1.0 (2018-05-04)

* First release on PyPI.
