=======
Credits
=======

Contributors
------------

* Bennett Cyphers <bcyphers@mit.edu>
* Thomas Swearingen <swearin3@msu.edu>
* Kalyan Veeramachaneni <kveerama.su@gmail.com>
* Laura Gustafson <lgustaf@mit.edu>
* Carles Sala <c.sala.stq@gmail.com>
* Micah Smith <micahjsmith@gmail.com>
* Kiran Karra <kiran.karra@gmail.com>
* swearin3 <swearin3@msu.edu>
* Max Kanter <kmax12@gmail.com>
* cclauss <cclauss@bluewin.ch>
* Alfredo Cuesta-Infante <alfredo.cuesta@urjc.es>
* wheuuchuu <weilian@mit.edu>
* Matteo Hoch <minime@hochweb.com>
* Favio André Vázquez <favio.vazquezp@gmail.com>
